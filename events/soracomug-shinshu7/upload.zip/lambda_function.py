from twilio.rest import Client
import os

def lambda_handler(event, context):
    # 入力値処理
    twilio_sid = os.environ['twilio_sid']
    twilio_token = os.environ['twilio_token']
    twilio_flowid = os.environ['twilio_flowid']
    twilio_number = os.environ['twilio_number']
    twilio_callto = os.environ['twilio_callto']

    client = Client(twilio_sid, twilio_token)
    execution = client.studio.flows(twilio_flowid).executions.create(
        to=twilio_callto,
        from_=twilio_number
    )

    return execution.sid

